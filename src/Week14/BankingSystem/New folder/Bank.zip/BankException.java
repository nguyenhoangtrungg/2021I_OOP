

public class BankException extends Exception {

  public BankException(String input) {
    super(input);
  }
}
