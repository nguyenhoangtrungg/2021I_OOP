import java.util.ArrayList;

public class Account {

  private double balance;
  private ArrayList<Transaction> arrayList = new ArrayList<>();
  /**
   * hi.
   * @param amount .
   */
  public void deposit(double amount) {
    if (amount > 0) {
      balance += amount;
    } else {
      System.out.println("So tien ban nap vao khong hop le!");
    }
  }

  /**
   * hi.
   * @param amount .
   */
  public void withdraw(double amount) {
    if (amount > balance) {
      System.out.println("So tien ban rut vuot qua so du!");
    } else if (amount > 0) {
      balance -= amount;
    } else {
      System.out.println("So tien ban rut ra khong hop le!");
    }
  }

  /**
   * hi.
   * @param amount .
   * @param operation .
   */
  public void addTransaction(double amount, String operation) {
    if (operation.equals(Transaction.DEPOSIT)) {
      deposit(amount);
      arrayList.add(new Transaction(Transaction.DEPOSIT, amount, this.balance));

    } else if (operation.equals(Transaction.WITHDRAW)) {
      withdraw(amount);
      arrayList.add(new Transaction(Transaction.WITHDRAW, amount, this.balance));
    } else {
      System.out.println("Yeu cau khong hop le!");
    }
  }

  /**
   * hi.
   */
  public void printTransaction() {
    for (int i = 0; i < arrayList.size(); i++) {
      double am = arrayList.get(i).getAmount();
      double bl = arrayList.get(i).getBalance();
      if (arrayList.get(i).getOperation().equals(Transaction.DEPOSIT)) {
        System.out.printf("Giao dich %d: ", i + 1);
        System.out.printf("Nap tien $%.2f. ", am);
        System.out.printf("So du luc nay: $%.2f.\n", bl);
      } else {
        System.out.printf("Giao dich %d: ", i + 1);
        System.out.printf("Rut tien $%.2f. ", am);
        System.out.printf("So du luc nay: $%.2f.\n", bl);
      }
    }
  }
  public static void main(String[] args) {

  }
}
